export class Api{
baseUrl:string="https://eswar-trip-advisor-api-dev.azurewebsites.net"
}