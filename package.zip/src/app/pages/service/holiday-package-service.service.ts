import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { Api } from "src/assets/Api";

@Injectable({
  providedIn: "root"
})
export class HolidayPackageServiceService {
  api = new Api();
  private url = this.api.baseUrl + "/place/getpackage/";
  constructor(private http: HttpClient) {}

  getPackage(dest: any): Observable<any> {
    return this.http.get(this.url + dest);
  }
}
