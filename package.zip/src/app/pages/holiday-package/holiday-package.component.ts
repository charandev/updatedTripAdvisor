import { Component, OnInit, Inject } from "@angular/core";
import { HolidayPackageServiceService } from "../service/holiday-package-service.service";
import { NgxSpinnerService } from "ngx-spinner";
@Component({
  selector: "app-holiday-package",
  templateUrl: "./holiday-package.component.html",
  styleUrls: ["./holiday-package.component.scss"]
})
export class HolidayPackageComponent implements OnInit {
  errorStatus=false;
  errorMessage:any;
  source: any;
  destination: any;
  date: any;
  holiday: any;
  packages: any;
  constructor(
    @Inject(HolidayPackageServiceService)
    private holidayService: HolidayPackageServiceService,
    private spinner: NgxSpinnerService
  ) {}

  ngOnInit() {}
  enableFilter() {
    this.errorStatus=false;
    this.spinner.show();
    this.holidayService.getPackage(this.destination).subscribe(data => {
      this.spinner.hide();
      this.holiday = data;
      // this.childPackage.getPlace(this.holiday);
      this.packages = this.holiday.packages;
      console.log(this.packages);
    },error=>{
      this.errorStatus=true;
      this.spinner.hide();
      this.errorMessage=error;
      console.log(error);
      
    });
  }
}
