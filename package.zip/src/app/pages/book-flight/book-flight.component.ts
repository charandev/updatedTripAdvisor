import { Component, OnInit } from "@angular/core";
import { FlightService } from "../service/flight.service";
import * as moment from "moment";
import { NgxSpinnerService } from "ngx-spinner";
@Component({
  selector: "app-book-flight",
  templateUrl: "./book-flight.component.html",
  styleUrls: ["./book-flight.component.scss"]
})
export class BookFlightComponent implements OnInit {
  // source:any=source;
  // destinatio
  status: boolean = false;
  source: any;
  destination: any;
  date: any;
  err: any;
  flightdata: any[] = [];
  constructor(
    private service: FlightService,
    private spinner: NgxSpinnerService
  ) {}

  ngOnInit() {}

  enableFilter() {
    this.spinner.show()
    
    const momentDate = new Date(this.date); // Replace event.value with your date value
    const formattedDate = moment(momentDate).format("YYYYMMDD");
    

    this.service
      .getFlight(this.source, this.destination, formattedDate)
      .subscribe(
        
        info => {
          this.spinner.hide()
          let infodata = info["data"];
          let flight_data = infodata["onwardflights"];
          this.flightdata = flight_data;
          // console.log(this.flightdata);
        },
        error => {
          this.err = "No Data Fetched";
        }
        
      );
      this.status = true;
  }
}
